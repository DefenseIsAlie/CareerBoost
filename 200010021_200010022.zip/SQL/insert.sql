INSERT INTO Skill
VALUES
("1", "SQL"),
("2", "Jsp"),
("3", "HTML"),
("4", "CSS"),
("5", "Eclipse IDE");

INSERT INTO has_skill
VALUES
("abhi", "1"),
("abhi", "2"),
("abhi", "5");